package com.example.OurHand

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
